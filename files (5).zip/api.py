# ============================================================
# api.py — API FastAPI Eagle-1 / AstroDynamics
# Backend RL : toute la logique côté serveur
# Lancement : uvicorn src.api:app --host 0.0.0.0 --port 8000
# ============================================================

# — Bibliothèques standard
import base64                        # encodage frames en base64
import io                            # flux mémoire pour images
import json                          # lecture métadonnées JSON
import sys                           # manipulation du path Python
from pathlib import Path             # chemins portables
from typing  import List, Optional   # annotations de types

# — Web framework
import uvicorn                       # serveur ASGI
from fastapi             import FastAPI, HTTPException  # framework API
from fastapi.middleware.cors import CORSMiddleware      # CORS pour Streamlit
from pydantic            import BaseModel              # validation données

# — Calcul vectoriel et image
import numpy             as np       # tableaux numériques
from PIL                 import Image  # conversion frame numpy → PNG

# — Environnement et modèle RL
import gymnasium         as gym      # API Gymnasium 1.3+
from stable_baselines3   import PPO, DQN  # algorithmes SB3

# ----------------------------------------------------------
# Configuration des chemins
# ----------------------------------------------------------
try:
    import google.colab
    BASE = Path('/content/drive/MyDrive/OpenClassrooms/m11_ocr')
except ImportError:
    BASE = Path(__file__).resolve().parent.parent  # src/ → m11_ocr/

MODELS = BASE / 'models'

# ----------------------------------------------------------
# Noms des actions LunarLander-v3
# ----------------------------------------------------------
NOMS_ACTIONS = {
    0: "do nothing",
    1: "moteur gauche",
    2: "moteur principal",
    3: "moteur droit",
}

# ============================================================
# Chargement du modèle au démarrage (une seule fois)
# ============================================================

def _trouver_meilleur_modele():
    """
    Cherche le meilleur modèle disponible dans models/.
    Priorité : best_ppo/best_model.zip > ppo_*.zip > dqn_*.zip
    Retourne (chemin_zip, algorithme, chemin_json ou None)
    """
    # 1. Modèle best_ppo (sauvegarde EvalCallback)
    chemin_best = MODELS / 'best_ppo' / 'best_model.zip'
    if chemin_best.exists():
        # Chercher le JSON correspondant
        jsons = sorted(MODELS.glob('ppo_lunarlander_*.json'), reverse=True)
        json_path = jsons[0] if jsons else None
        return chemin_best, 'PPO', json_path

    # 2. Dernier modèle PPO avec score dans le nom
    ppo_zips = sorted(MODELS.glob('ppo_lunarlander_*.zip'), reverse=True)
    if ppo_zips:
        stem     = ppo_zips[0].stem
        json_p   = MODELS / f'{stem}.json'
        return ppo_zips[0], 'PPO', json_p if json_p.exists() else None

    # 3. Dernier modèle DQN
    dqn_zips = sorted(MODELS.glob('*dqn_lunarlander_*.zip'), reverse=True)
    if dqn_zips:
        stem     = dqn_zips[0].stem
        json_p   = MODELS / f'{stem}.json'
        return dqn_zips[0], 'DQN', json_p if json_p.exists() else None

    return None, None, None


chemin_modele, algo, chemin_json = _trouver_meilleur_modele()

if chemin_modele is None:
    print("⚠ Aucun modèle trouvé dans models/ — API en mode dégradé")
    model    = None
    metadata = {}
else:
    print(f"  Modèle chargé...........: {chemin_modele}")
    print(f"  Algorithme..............: {algo}")
    model = (PPO if algo == 'PPO' else DQN).load(str(chemin_modele))
    metadata = {}
    if chemin_json and chemin_json.exists():
        with open(chemin_json, encoding='utf-8') as f:
            metadata = json.load(f)
        print(f"  Métadonnées JSON........: {chemin_json.name}")

# ============================================================
# Application FastAPI
# ============================================================

app = FastAPI(
    title       = "Eagle-1 RL API",
    description = "Backend RL pour le pilote automatique Eagle-1 — AstroDynamics",
    version     = "1.0.0",
)

# CORS : autoriser les requêtes depuis Streamlit (port 8501/8502)
app.add_middleware(
    CORSMiddleware,
    allow_origins  = ["*"],
    allow_methods  = ["*"],
    allow_headers  = ["*"],
)

# ============================================================
# Modèles Pydantic — validation des données entrantes
# ============================================================

class EtatRequest(BaseModel):
    """Vecteur d'état obs[8] envoyé par le GUI."""
    state: List[float]               # 8 variables continues


class EpisodeRequest(BaseModel):
    """Paramètres optionnels pour jouer un épisode complet."""
    seed: Optional[int] = 42         # graine reproductibilité
    render: Optional[bool] = True    # générer les frames RGB


# ============================================================
# Fonctions utilitaires
# ============================================================

def _frame_vers_base64(frame: np.ndarray) -> str:
    """
    Convertit une frame RGB numpy (H, W, 3) en chaîne base64 PNG.
    Utilisé pour transmettre les images au GUI sans fichiers temporaires.
    """
    img    = Image.fromarray(frame.astype(np.uint8))
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    return base64.b64encode(buffer.getvalue()).decode('utf-8')


def _verifier_modele():
    """Lève une erreur HTTP 503 si le modèle n'est pas chargé."""
    if model is None:
        raise HTTPException(
            status_code = 503,
            detail      = "Aucun modèle disponible. Entraîner un agent d'abord."
        )


# ============================================================
# Endpoints
# ============================================================

# ####################################################################
# GET /health — état du service
# ####################################################################
@app.get("/health")
def health():
    """
    Vérifie que l'API est opérationnelle et retourne les infos du modèle.
    Utilisé par le GUI pour afficher l'indicateur de connexion.
    """
    return {
        "status"       : "ok" if model is not None else "degraded",
        "modele"       : str(chemin_modele.name) if chemin_modele else None,
        "algorithme"   : algo,
        "mean_reward"  : metadata.get('resultats', {}).get('mean_reward'),
        "critere_valide": metadata.get('resultats', {}).get('critere_valide'),
        "environnement": metadata.get('environnement', 'LunarLander-v3'),
    }


# ####################################################################
# POST /action — prédire une action depuis un état
# ####################################################################
@app.post("/action")
def predict_action(req: EtatRequest):
    """
    Reçoit un vecteur d'état obs[8] et retourne l'action optimale.
    Endpoint principal utilisé par le GUI en mode pas à pas.
    """
    _verifier_modele()

    if len(req.state) != 8:
        raise HTTPException(
            status_code = 422,
            detail      = f"State doit contenir 8 valeurs, reçu {len(req.state)}"
        )

    obs    = np.array(req.state, dtype=np.float32)
    action, _ = model.predict(obs, deterministic=True)
    action    = int(action)

    return {
        "action"      : action,
        "action_name" : NOMS_ACTIONS.get(action, "inconnu"),
    }


# ####################################################################
# POST /episode — jouer un épisode complet
# ####################################################################
@app.post("/episode")
def jouer_episode(req: EpisodeRequest):
    """
    Exécute un épisode complet avec le modèle chargé.
    Retourne frames (base64 PNG), récompenses, actions,
    observations et métriques de l'épisode.
    Toute la logique RL reste côté API — le GUI ne touche pas au modèle.
    """
    _verifier_modele()

    # Créer l'environnement avec render_mode selon la demande
    render_mode = "rgb_array" if req.render else None
    env         = gym.make("LunarLander-v3", render_mode=render_mode)
    obs, _      = env.reset(seed=req.seed)

    # ----------------------------------------------------------
    # Listes de collecte pour l'épisode
    # ----------------------------------------------------------
    frames_b64      = []     # frames PNG encodées en base64
    rewards_cumules = []     # récompense cumulée à chaque pas
    actions_list    = []     # action choisie à chaque pas
    obs_list        = []     # observation à chaque pas
    reward_cumule   = 0.0    # accumulateur
    terminated      = False
    truncated       = False

    # ----------------------------------------------------------
    # Boucle d'épisode
    # ----------------------------------------------------------
    while not (terminated or truncated):

        # Capturer la frame AVANT l'action
        if req.render:
            frame = env.render()
            frames_b64.append(_frame_vers_base64(frame))

        # Prédiction déterministe du modèle
        action, _                         = model.predict(obs, deterministic=True)
        action                            = int(action)
        obs, reward, terminated, truncated, _ = env.step(action)

        reward_cumule  += float(reward)
        rewards_cumules.append(round(reward_cumule, 3))
        actions_list.append(action)
        obs_list.append([round(float(v), 5) for v in obs])

    env.close()

    return {
        "frames"       : frames_b64,
        "rewards"      : rewards_cumules,
        "actions"      : actions_list,
        "obs"          : obs_list,
        "total_reward" : round(reward_cumule, 2),
        "n_steps"      : len(actions_list),
        "success"      : reward_cumule >= 200.0,
        "seed"         : req.seed,
    }


# ####################################################################
# GET /model/info — métadonnées complètes du modèle
# ####################################################################
@app.get("/model/info")
def model_info():
    """
    Retourne les métadonnées complètes du modèle chargé :
    hyperparamètres, résultats d'évaluation, baseline, comparaison DQN.
    Utilisé par l'onglet 'Modèle' du GUI.
    """
    _verifier_modele()

    if not metadata:
        return {
            "message"    : "Pas de métadonnées JSON disponibles",
            "modele"     : str(chemin_modele.name),
            "algorithme" : algo,
        }

    return metadata


# ============================================================
# Point d'entrée direct (python src/api.py)
# ============================================================
if __name__ == "__main__":
    uvicorn.run(
        "api:app",
        host    = "0.0.0.0",
        port    = 8000,
        reload  = False,
    )
